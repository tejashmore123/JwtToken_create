package jwtpack.ControllertoAuthenticate;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jwtpack.UserCredentials.UserCredentials;
import jwtpack.util.JwtUtil;

@RestController
@RequestMapping("/api")
public class AuthenticationController {

    private JwtUtil jwtUtil = new JwtUtil();
    private static final String HARD_CODED_USERNAME = "Tejash";
    private static final String HARD_CODED_PASSWORD = "1234";
    // POST method for generating token
    @PostMapping("/authenticate")
    public ResponseEntity<String> createToken(@RequestBody UserCredentials credentials) {
        // Normally, you'd authenticate the user using a service and password check
        // For simplicity, we'll skip that and assume valid credentials
        String token = jwtUtil.generateToken(credentials.getUsername());
        return ResponseEntity.ok(token);
    }

    // GET method that requires token validation
    @GetMapping("/secure-data")
    public ResponseEntity<String> getSecureData(@RequestHeader("Authorization") String authorizationHeader) {
        // Extract the token from the Authorization header
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            String token = authorizationHeader.substring(7);  // Remove "Bearer " prefix

            try {
                // Validate the token
                String username = jwtUtil.extractUsername(token);
                if (username != null && jwtUtil.validateToken(token, username)) {
                    // If token is valid, return some secure data
                    return ResponseEntity.ok("Secure data accessed by " + username);
                } else {
                    // Token is invalid or expired
                    return ResponseEntity.status(401).body("Unauthorized - Token is invalid or expired");
                }
            } catch (Exception e) {
                // Handle any exceptions, e.g., invalid token format
                return ResponseEntity.status(401).body("Unauthorized - Token validation failed");
            }
        } else {
            // If the Authorization header is missing or incorrectly formatted
            return ResponseEntity.status(401).body("Unauthorized - Missing or invalid Authorization header");
        }
    }
}
