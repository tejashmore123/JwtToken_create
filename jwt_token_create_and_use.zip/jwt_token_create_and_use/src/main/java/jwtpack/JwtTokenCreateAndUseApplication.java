package jwtpack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtTokenCreateAndUseApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtTokenCreateAndUseApplication.class, args);
	}

}
